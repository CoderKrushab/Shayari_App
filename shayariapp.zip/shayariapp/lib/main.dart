import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shayariapp/secondpage.dart';
import 'package:shayariapp/shayri.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: shayridemo(),
    theme:
        ThemeData(primaryColor: Color(0xffD9AFD9), primarySwatch: Colors.cyan),
  ));
}

class shayridemo extends StatefulWidget {
  const shayridemo({Key? key}) : super(key: key);

  @override
  State<shayridemo> createState() => _shayridemoState();
}

class _shayridemoState extends State<shayridemo> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffCAE2DE),
      appBar: AppBar(
        title: Text(
          "शायरी",
          style: TextStyle(fontSize: 40, color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return Card(
            elevation: 20,
            child: ListTile(
              leading: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        image: AssetImage("photo/${shayri.photo[index]}"),
                        fit: BoxFit.fill)),
              ),
              tileColor: Theme.of(context).primaryColor,
              title: Text(
                shayri.name[index],
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              trailing: Icon(
                Icons.arrow_forward,
                color: Colors.black87,
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return secondpage(index, shayri.name);
                  },
                ));
              },
            ),
          );
        },
        itemCount: shayri.name.length,
      ),
    );
  }
}
