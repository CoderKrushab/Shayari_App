import 'package:flutter/material.dart';

import 'package:shayariapp/shayri.dart';
import 'package:shayariapp/thrdpage.dart';

class secondpage extends StatefulWidget {
  int index;
  List<String> name;

  secondpage(this.index, this.name);

  @override
  State<secondpage> createState() => _secondpageState();
}

class _secondpageState extends State<secondpage> {
  List<String> temp = [];

  @override
  void initState() {
    super.initState();

    switch (widget.index) {
      case 0:
        temp = shayri.friendship;

        break;
      case 1:
        temp = shayri.funny;
        break;
      case 2:
        temp = shayri.hurt;
        break;
      case 3:
        temp = shayri.india;
        break;
      case 4:
        temp = shayri.love;
        break;
      case 5:
        temp = shayri.morning;
        break;
      case 6:
        temp = shayri.night;
        break;
      case 7:
        temp = shayri.single;
        break;
      case 8:
        temp = shayri.sorry;
        break;
      case 9:
        temp = shayri.think;
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffCAE2DE),
      appBar: AppBar(
        title: Text("${widget.name[widget.index]}"),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return Card(
            elevation: 10,
            color: Color(0xffD9AFD9),

            margin: EdgeInsets.all(5),
            child: ListTile(
              title: Text(
                "${temp[index]}",
                style: TextStyle(fontSize: 20, color: Colors.black87),
                maxLines: 1,
              ),
              leading: Image.asset(
                "photo/${shayri.photo[widget.index]}",
              ),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return thrdpage(index, widget.name[index], temp);
                  },
                ));
              },
            ),
          );
        },
        itemCount: temp.length,
      ),
    );
  }
}
