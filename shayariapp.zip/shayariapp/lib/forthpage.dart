

import 'package:flutter/material.dart';
import 'package:shayariapp/shayri.dart';

class forthpage extends StatefulWidget {
  int index;
  List<String> temp;

  forthpage(this.index, this.temp);

  @override
  State<forthpage> createState() => _forthpageState();
}

class _forthpageState extends State<forthpage> {
  Color bgcolor = Color(0xffEACFEA);

  TextAlign t = TextAlign.center;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffCAE2DE),
        appBar: AppBar(
          shadowColor: Colors.pink,
          elevation: 10,
          title: Text("${widget.index + 1} / ${widget.temp.length}"),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Expanded(
              flex: 5,
              child: Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: bgcolor,
                  // gradient: LinearGradient(
                  //   colors: [Color(0xffEACFEA), Color(0xffD9AFD9)],
                  // ),
                  borderRadius: BorderRadius.circular(10),
                ),
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.all(21),
                alignment: Alignment.center,
                child: Text(
                  textAlign: t,
                  "${widget.temp[widget.index ]}",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  height: double.infinity,
                  //color: Colors.brown,
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    color: Colors.pink,
                    gradient: LinearGradient(
                      colors: [Color(0xffEACFEA), Color(0xffD9AFD9)],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  margin: EdgeInsets.all(15),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: Container(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    t = TextAlign.center;
                                    setState(() {});
                                  },
                                  icon: Icon(
                                    Icons.format_align_center_rounded,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                              IconButton(
                                  onPressed: () {
                                    t = TextAlign.justify;
                                    setState(() {});
                                  },
                                  icon: Icon(
                                    Icons.format_align_justify_rounded,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                              IconButton(
                                  onPressed: () {
                                    int R =
                                        shayri.r.nextInt(shayri.colo.length);
                                    bgcolor = shayri.colo[R];

                                    setState(() {});
                                  },
                                  icon: Icon(
                                    Icons.wifi_protected_setup_rounded,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                              IconButton(
                                  onPressed: () {},
                                  icon: Icon(
                                    Icons.zoom_out_map_sharp,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                              IconButton(
                                  onPressed: () {
                                    t = TextAlign.left;
                                    setState(() {});
                                  },
                                  icon: Icon(
                                    Icons.format_align_left_rounded,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                              IconButton(
                                  onPressed: () {
                                    t = TextAlign.right;
                                    setState(() {});
                                  },
                                  icon: Icon(
                                    Icons.format_align_right_rounded,
                                    size: 25,
                                    color: Colors.black,
                                  )),
                            ],
                          ),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                           // color: Color(0xffCAE2DE),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          margin: EdgeInsets.all(15),
                          height: 120,

                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Backgound",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Text Color",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Share",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Font",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Emoji",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shadowColor: Color(0xffCAE2DE),
                                primary: Color(0xffCAE2DE),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5)),
                                fixedSize: Size(105, 35),
                              ),
                              onPressed: () {},
                              child: Text(
                                "Text Size",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold, // light
                                ),
                              )),
                        ],
                      )
                    ],
                  ),
                )),
          ],
        ));
  }
}
