package com.example.shayariapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
